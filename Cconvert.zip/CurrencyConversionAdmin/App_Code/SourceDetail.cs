﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurrencyConversionAdmin.App_Code
{
    public class SourceDetail
    {
        public string sourcename { get; set; }
        //public string sourcename { get; set; }
    }
}