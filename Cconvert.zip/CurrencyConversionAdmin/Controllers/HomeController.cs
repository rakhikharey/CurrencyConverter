﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CurrencyConversionAdmin.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Success()
        {
            return View();
        }
        public ActionResult Index()
        {
            return View();
        }

    }
}
