﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using CurrencyConversionAdmin.Models;
using System.Data.Entity.Core.Objects;

namespace CurrencyConversionAdmin.Controllers
{
    public class SourceController : Controller
    {
        //
        // GET: /User/
        public ActionResult Index()
        {
            return View();
        }
        

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Models.LoginUser_Result user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new Models.cconverterEntities())
                    {
                        var source = db.sourcemasters.FirstOrDefault(u => u.userid == user.userid);
                        if (source == null)
                        {
                            var encrypPass = user.passcode;
                            var crypto = new SimpleCrypto.PBKDF2();
                            if (user.passcode != null)
                            {
                                encrypPass = crypto.Compute(user.passcode);
                            }
                            else
                                crypto.Salt = null;
                            //ObjectParameter passcode = new ObjectParameter("passcode", typeof(string));
                            db.SaveSource(user.sourcename, user.loginrequired, user.userid, user.isAdmin, user.createddate, user.IPAddress, crypto.Salt, encrypPass);
                            return RedirectToAction("Success", "Home");
                        }else
                            ModelState.AddModelError("", "User already exists");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Data is not correct");
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }

            return View();
        }


        [HttpGet]
        public ActionResult CurrencyRates()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CurrencyRates(Models.CurRate crate)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new Models.cconverterEntities())
                    {
                        //ObjectParameter passcode = new ObjectParameter("passcode", typeof(string));
                        db.AddCurrencyRate(crate.fromC, crate.toC, crate.rate);
                        return RedirectToAction("Success", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Data is not correct");
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }

            return View();
        }


        [HttpGet]
        public ActionResult Disable()
        {
            List<SelectListItem> sourcelist = new List<SelectListItem>();
            var db = new Models.cconverterEntities();

            var sourcemasters = db.GetSourceList("12345");

            foreach (sourcemaster s in sourcemasters)
            {
                sourcelist.Add(new SelectListItem
                {
                    Text = s.sourcename,
                    Value = s.id.ToString()
                });
            }

            ViewBag.sourcelist = sourcelist;
            return View();
        }
        [HttpPost]
        public ActionResult Disable(Models.sourcemaster user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new Models.cconverterEntities())
                    {
                        db.disablesource(user.id, "1234567", false);
                        return RedirectToAction("Success", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Data is not correct");
                }
                ObjectParameter passcode = new ObjectParameter("passcode", typeof(string));
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }

            return View();
        }

        

        private bool IsValid(string user_id, string password)
        {
            var crypto = new SimpleCrypto.PBKDF2();
            bool IsValid = false;

            using (var db = new Models.cconverterEntities())
            {
                var user = db.sourcemasters.FirstOrDefault(u => u.userid == user_id);
                if (user != null)
                {
                    if (user.passcode == crypto.Compute(password, user.passwordsalt))
                    {
                        IsValid = true;
                    }
                }
            }
            return IsValid;
        }

    }
}
